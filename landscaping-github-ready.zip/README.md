# Landscaping Designer App

## Run locally
npm install
npm start

## Deploy
Upload to GitHub, then import into Vercel.
