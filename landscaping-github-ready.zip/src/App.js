import React, { useState } from "react";

export default function App() {
  const [plants, setPlants] = useState([]);
  const [yardPlants, setYardPlants] = useState([]);
  const [name, setName] = useState("");
  const [image, setImage] = useState(null);
  const [blendMode, setBlendMode] = useState(false);
  const [background, setBackground] = useState(null);

  const handleAddPlant = () => {
    if (!name || !image) return;
    const newPlant = {
      id: Date.now(),
      name,
      image: URL.createObjectURL(image),
    };
    setPlants([...plants, newPlant]);
    setName("");
    setImage(null);
  };

  const addToYard = (plant) => {
    setYardPlants([
      ...yardPlants,
      { ...plant, x: 50, y: 50, id: Date.now() },
    ]);
  };

  const handleDrag = (e, id) => {
    const rect = e.currentTarget.parentElement.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setYardPlants((prev) =>
      prev.map((p) => (p.id === id ? { ...p, x, y } : p))
    );
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>🌿 Landscaping Designer</h1>

      <div>
        <input type="file" onChange={(e) =>
          setBackground(URL.createObjectURL(e.target.files[0]))
        } />
      </div>

      <button onClick={() => setBlendMode(!blendMode)}>
        {blendMode ? "Disable Blend" : "Enable Blend"}
      </button>

      <div>
        <input value={name} onChange={(e)=>setName(e.target.value)} placeholder="Plant name"/>
        <input type="file" onChange={(e)=>setImage(e.target.files[0])}/>
        <button onClick={handleAddPlant}>Add Plant</button>
      </div>

      <div style={{ display:"flex", gap:10 }}>
        {plants.map(p=>(
          <div key={p.id} onClick={()=>addToYard(p)}>
            <img src={p.image} width={60}/>
            <p>{p.name}</p>
          </div>
        ))}
      </div>

      <div style={{
        position:"relative",
        height:400,
        border:"1px solid #ccc",
        background: background ? `url(${background}) center/cover` : "#d4f5d4"
      }}>
        {yardPlants.map(p=>(
          <img
            key={p.id}
            src={p.image}
            draggable
            onDragEnd={(e)=>handleDrag(e,p.id)}
            style={{
              position:"absolute",
              left:p.x,
              top:p.y,
              width:60,
              opacity: blendMode?0.8:1,
              mixBlendMode: blendMode?"multiply":"normal"
            }}
          />
        ))}
      </div>
    </div>
  );
}
